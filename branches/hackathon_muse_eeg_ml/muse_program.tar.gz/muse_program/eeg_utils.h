#ifndef EEG_UTILS_H
#define EEG_UTILS_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


void get_eeg_sample(double* sample, int label, int n);
void randsample(int array[], int n);


#endif
