/**
 * @file fft_testbench.c
 * @author Fr�d�ric Simard
 * @date January, 2015
 * @brief This program test my specific needs for the fft. The fft implementation
 * satisfy my requirements in all but one respect. My data points are real-valued,
 * but the fft implementation perform the operation on complex data points.
 *
 * The naive approach is to pad the imaginary part with 0s. While this result in
 * a symmetric, but correct fft, it performs the operation on a 2*N long sequence, where
 * 2*N correspond to the length of the real-valued sequence.
 *
 * It is possible, however, to split the real-valued data to obtain a N long complex-sequence.
 * This approach greatly improve the efficiency of the operation, but require a few manipulations
 * before and after the fft to proceed this way. This program implements and test this approach.
 *
 * Frederic Simard, Atom Embedded, www.atomsproducts.com, 2015
 * based on: Matusiak R (2001) Implementing Fast Fourir Transform Algorithms of 
 * Real-Valued Sequences With the TMS320 DSP Platotform. Application Report. SPRA291
 *
 * See below for original copyrights and licensing details of the fft and convolution test library.
 *
 * Copyright (c) 2014 Project Nayuki
 * http://www.nayuki.io/page/free-small-fft-in-multiple-languages
 * 
 * (MIT License)
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 * - The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 * - The Software is provided "as is", without warranty of any kind, express or
 *   implied, including but not limited to the warranties of merchantability,
 *   fitness for a particular purpose and noninfringement. In no event shall the
 *   authors or copyright holders be liable for any claim, damages or other
 *   liability, whether in an action of contract, tort or otherwise, arising from,
 *   out of or in connection with the Software or the use or other dealings in the
 *   Software.
 */ 

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fft.h"
#include "svm.h"
#include "muse_program_test.h"

using namespace std;

#define SAMPLES_LENGTH 220
#define NB_TRAIN_SAMPLES 40

/**
 * main(int argc, char **argv[])
 * 
 * @brief this program test the fast-fourier transform for 
 *        2*N real-valued signal, under various conditions
 * @param argc
 * @param argv
 * @return 0 for success, non-zero for failure
 */ 
 int main(int argc, char **argv) {
	int i,j;
	double* training_raw_samples = (double*)malloc(sizeof(double)*NB_TRAIN_SAMPLES*SAMPLES_LENGTH);
	double** training_alpha_samples = (double**)malloc(sizeof(double*)*NB_TRAIN_SAMPLES);
	int* training_labels = (int*)malloc(sizeof(int)*NB_TRAIN_SAMPLES);
	
	double* test_raw_sample_a = (double*)malloc(sizeof(double)*SAMPLES_LENGTH);
	double* test_raw_sample_b = (double*)malloc(sizeof(double)*SAMPLES_LENGTH);
	double* test_alpha_sample_a = (double*)malloc(sizeof(double)*2);
	double* test_alpha_sample_b = (double*)malloc(sizeof(double)*2);
	
	double* temp_samples_a = (double*)malloc(sizeof(double)*SAMPLES_LENGTH);
	double* temp_samples_b = (double*)malloc(sizeof(double)*SAMPLES_LENGTH);
	
	double temp_sum_a;
	double temp_sum_b;
	
	double predicted_label_a;
	double predicted_label_b;
	
	t_svm_options options;
	t_svm* psvm;
	
	srand(time(NULL));
	
	for(i=0;i<40;i++){
		training_alpha_samples[i] = (double*)malloc(sizeof(double)*2);
	}
	
	//test_real_valued_fft(220);
	//test_svm();
	
	/*Generate a training dataset*/
	for(i=0;i<40;i++){
		
		if((float)rand()/((float)RAND_MAX)<0.5){
			get_eeg_sample(&(training_raw_samples[i*SAMPLES_LENGTH]),0,SAMPLES_LENGTH);
			training_labels[i] = -1;
		}
		else{
			get_eeg_sample(&(training_raw_samples[i*SAMPLES_LENGTH]),1,SAMPLES_LENGTH);
			training_labels[i] = 1;
		}
	}
	
	
	/*Convert each training samples*/
	for(i=0;i<40;i+=2){
		/*compute fft*/
		abs_fft_2signals(&(training_raw_samples[i*SAMPLES_LENGTH]),&(training_raw_samples[(i+1)*SAMPLES_LENGTH]),temp_samples_a,temp_samples_b,SAMPLES_LENGTH);
		
		/*average over alpha frequencies*/
		temp_sum_a = 0.0;
		temp_sum_b = 0.0;
		for(j=7;j<15;j++){
			temp_sum_a += temp_samples_a[j];
			temp_sum_b += temp_samples_b[j];
		}
		temp_sum_a /= 11*8;
		temp_sum_b /= 11*8;
		
		/*save to training dataset*/
		training_alpha_samples[i][0] = temp_sum_a;
		training_alpha_samples[i+1][0] = temp_sum_b;
		
		/*average over XXXX frequencies*/
		temp_sum_a = 0.0;
		temp_sum_b = 0.0;
		for(j=20;j<25;j++){
			temp_sum_a += temp_samples_a[j];
			temp_sum_b += temp_samples_b[j];
		}
		temp_sum_a /= 11*8;
		temp_sum_b /= 11*8;
		
		training_alpha_samples[i][1] = temp_sum_a;
		training_alpha_samples[i+1][1] = temp_sum_b;
	}
	
	for(i=10;i<30;i++){
		printf("%i %f\n",training_labels[i],training_alpha_samples[i][1]);
	}
	
	/*Train the svm*/
	options.nb_samples = 40;
	options.nb_features = 2;
	
	/*train the svm*/
	psvm = train_svm(training_alpha_samples, training_labels, options);
	
	/*Run time*/
	for(i=0;i<10;i++){
	
		/*generate a sample*/
		get_eeg_sample(test_raw_sample_a,1,SAMPLES_LENGTH);
		get_eeg_sample(test_raw_sample_b,0,SAMPLES_LENGTH);
		
		abs_fft_2signals(test_raw_sample_a,test_raw_sample_b,temp_samples_a,temp_samples_b,SAMPLES_LENGTH);
		
		/*average over alpha frequencies*/
		temp_sum_a = 0.0;
		temp_sum_b = 0.0;
		for(j=7;j<15;j++){
			temp_sum_a += temp_samples_a[j];
			temp_sum_b += temp_samples_b[j];
		}
		temp_sum_a /= 11*8;
		temp_sum_b /= 11*8;
		
		/*save to training dataset*/
		test_alpha_sample_a[0] = temp_sum_a;
		test_alpha_sample_b[0] = temp_sum_b;
		
		/*average over alpha frequencies*/
		temp_sum_a = 0.0;
		temp_sum_b = 0.0;
		for(j=20;j<25;j++){
			temp_sum_a += temp_samples_a[j];
			temp_sum_b += temp_samples_b[j];
		}
		temp_sum_a /= 11*8;
		temp_sum_b /= 11*8;
		
		/*save to training dataset*/
		test_alpha_sample_a[1] = temp_sum_a;
		test_alpha_sample_b[1] = temp_sum_b;
		
		/*classify it*/
		predicted_label_a = classify_with_svm(psvm,test_alpha_sample_a);
		predicted_label_b = classify_with_svm(psvm,test_alpha_sample_b);
		
		/*report the results*/
		printf("lbl_a: %f\n",predicted_label_a);
		printf("lbl_b: %f\n",predicted_label_b);
	
	}
	return 0;
}

