#include "muse_program_test.h"

using namespace std;

// Private function prototypes
static void naive_dft(const double *inreal, const double *inimag, double *outreal, double *outimag, int inverse, int n);
static double log10_rms_err(const double *xreal, const double *ximag, const double *yreal, const double *yimag, int n);
static double *random_reals(int n);
static void *memdup(const void *src, size_t n);
static double *zero_reals(int n);

static double max_log_error = -INFINITY;


#if 1
/**
 * test_real_valued_fft(int n)
 * 
 * @brief this function implements the test the fast-fourier transform for 2*N real-valued signal
 * @param n, the length of the fft to be computed. half the length of real-valued signal processes
 * @return none
 */ 
void test_real_valued_fft(int n) {

	int i,k;
	double signal_avg = 0.0;
	double *real_valued_signal, *real_valued_signal2;
	double *inputreal, *inputimag;
	double *refoutreal, *refoutimag;
	double *X1_abs, *X2_abs;
	
	/*Create a real-valued signal g(n)*/
	real_valued_signal = zero_reals(n);
	real_valued_signal2 = zero_reals(n);
	
	for(k=0;k<n;k++){
		real_valued_signal[k] = sin(M_PI *4*k / n);
		real_valued_signal2[k] = sin(M_PI *8*k / n);
		signal_avg += real_valued_signal[k]/n;
	}
	
	for(k=0;k<n;k++){
		real_valued_signal[k] -= signal_avg;
	}
	
	/*
	 **************************************************
	 * Reference: naive DFT
	 * This test is performed by padding the imaginary part of the signal with 0s
	 **************************************************
	*/
	
	/*perform the 2*N naive-dft by padding the imaginary part with 0s*/
	inputreal = (double*)memdup(real_valued_signal, n* sizeof(double));
	inputimag = zero_reals(n);
	refoutreal = (double*)malloc(n * sizeof(double));
	refoutimag = (double*)malloc(n * sizeof(double));
	naive_dft(inputreal, inputimag, refoutreal, refoutimag, 0, n);
	
	/*Terminate the test*/
	free(inputreal);
	free(inputimag);
	
	/*
	 **************************************************
	 * Test: N-FFT on complex signal
	 * This test rearrange the data to perform the fft on a complex signal formed from
	 * the original real-valued signal.
	 **************************************************
	*/
	
	/*form the complex signal x(n) = g1(n)+j*g2(n)*/
	inputreal = (double*)malloc(n * sizeof(double));
	inputimag = (double*)malloc(n * sizeof(double));
	
	for(i=0;i<n;i++){
		inputreal[i] = real_valued_signal[i];
		inputimag[i] = real_valued_signal2[i];
	}
	
	/*run the N-fft*/
	X1_abs = (double*)malloc(n * sizeof(double));
	X2_abs = (double*)malloc(n * sizeof(double));
	
	abs_fft_2signals(inputreal,inputimag,X1_abs,X2_abs,n);
	
	for(k=0;k<n;k++){
		printf("%0.4f %0.4f %0.4f\n",sqrt(refoutreal[k]*refoutreal[k]+refoutimag[k]*refoutimag[k]),X1_abs[k],X2_abs[k]);
	}
	
	/*Compare the results*/
	//printf("fftsize=%4d  logerr=%5.1f\n", n, log10_rms_err(refoutreal, refoutimag, actualoutreal, actualoutimag, 2*n));
	
	free(real_valued_signal);
	
	free(inputreal);
	free(inputimag);
	free(refoutreal);
	free(refoutimag);
	free(X1_abs);
	free(X2_abs);
}

#endif

/**
 * naive_dft(const double *inreal, const double *inimag, double *outreal, double *outimag, int inverse, int n)
 * 
 * @brief this function implements the reference naive fourier transform, by using the true definition.
  *       It is not optimal, but gives the correct result (this function was implemented by the original author)
 * @param inreal, inimag, complex signal to be processed
 * @param outreal, outimag, fourier transform of the signal
 * @param inverse, 1 to compute inverse transform, 0 for the forward transform
 * @param n, length of the signal
 * @return none
 */ 
static void naive_dft(const double *inreal, const double *inimag, double *outreal, double *outimag, int inverse, int n) {
	double coef = (inverse ? 2 : -2) * M_PI;
	int k;
	for (k = 0; k < n; k++) {  // For each output element
		double sumreal = 0;
		double sumimag = 0;
		int t;
		for (t = 0; t < n; t++) {  // For each input element
			double angle = coef * ((long long)t * k % n) / n;
			sumreal += inreal[t]*cos(angle) - inimag[t]*sin(angle);
			sumimag += inreal[t]*sin(angle) + inimag[t]*cos(angle);
		}
		outreal[k] = sumreal;
		outimag[k] = sumimag;
	}
}


/**
 * log10_rms_err(const double *xreal, const double *ximag, const double *yreal, const double *yimag, int n)
 * 
 * @brief this function implements the root mean square error criterion to compare two signals.
  *       (this function was implemented by the original author)
 * @param xreal, ximag, complex signal 1
 * @param yreal, yimag, complex signal 2
 * @param n, length of the signal
 * @return the rms of the difference between the two signals
 */ 
static double log10_rms_err(const double *xreal, const double *ximag, const double *yreal, const double *yimag, int n) {
	double err = 0;
	int i;
	for (i = 0; i < n; i++)
		err += (xreal[i] - yreal[i]) * (xreal[i] - yreal[i]) + (ximag[i] - yimag[i]) * (ximag[i] - yimag[i]);
	
	err /= n > 0 ? n : 1;
	err = sqrt(err);  // Now this is a root mean square (RMS) error
	err = err > 0 ? log10(err) : -99.0;
	if (err > max_log_error)
		max_log_error = err;
	return err;
}


/**
 * random_reals(int n)
 * 
 * @brief this function returns a vector of real elements.
  *       (this function was implemented by the original author)
 * @param n, length of the signal
 * @return 1 if success, 0 otherwise
 */ 
static double *random_reals(int n) {
	double *result = (double*)malloc(n * sizeof(double));
	int i;
	for (i = 0; i < n; i++)
		result[i] = (rand() / (RAND_MAX + 1.0)) * 2 - 1;
	return result;
}

/**
 * zero_reals(int n)
 * 
 * @brief this function returns a vector of 0s.
 * @param n, length of the signal
 * @return 1 if success, 0 otherwise
 */ 
static double *zero_reals(int n) {
	double *result = (double*)malloc(n * sizeof(double));
	int i;
	for (i = 0; i < n; i++)
		result[i] = 0;
	return result;
}


/**
 * memdup(int n)
 * 
 * @brief this function duplicates a memory array, size and values.
  *       (this function was implemented by the original author)
 * @param src, data to be duplicated
 * @param n, length of the signal
 * @return 1 if success, 0 otherwise
 */ 
static void *memdup(const void *src, size_t n) {
	void *dest = (double*)malloc(n);
	if (dest != NULL)
		memcpy(dest, src, n);
	return dest;
}



#if 1
int test_svm(){
	
	
	/* ------------------------------------------------------------------
	 * Define a small dataset: data and labels
	 * - 100 samples per class and 2 classes.
	 * - Samples have 10 features 
	 *     * one of them is correlated with the class id 
	 *     * a second one is anti-correlated.
	 * ------------------------------------------------------------------
	 */
	 
	int i,j;
	
	int tot_nb_samples = 200;
	int nb_train_samples = 180;
	int nb_test_samples = 20;
	int half_nb_samples = tot_nb_samples/2;
	
	int nb_of_features = 10;
	
	double **samples = (double**)malloc(sizeof(double*)*tot_nb_samples);
	int labels[tot_nb_samples];
	int labels_idx[tot_nb_samples]; // used to mix the samples
	double prdcted_labels[nb_test_samples]; // predicted labels (out of svm)
	
	int temp_a_id;
	int temp_b_id;
	
	/*the svms*/
	t_svm_options options;
	t_svm* psvm;
	t_svm* psvm2; //used for save/load test

	/*allocate feature memory for the samples*/
	for(i=0;i<tot_nb_samples;i++){
		samples[i] = (double*)malloc(sizeof(double)*nb_of_features);
	}
	
	/*
	 * Mix the samples
	 */
	 
	 /*Get a set of rand sample (random without duplication)*/
	randsample(labels_idx,tot_nb_samples);

	/*produce the feature vectors*/
	for(i=0;i<half_nb_samples;i++){
		temp_a_id = labels_idx[i];
		temp_b_id = labels_idx[i+half_nb_samples];
		labels[temp_a_id] = 1;
		labels[temp_b_id] = -1;
		
		/*baseline is independent*/
		for(j=0;j<10;j++){
			samples[temp_a_id][j] = (double)rand()/((double)RAND_MAX);
			samples[temp_b_id][j] = (double)rand()/((double)RAND_MAX);
		}
		
		/*both classes are anti-correlated*/
		
		/*class one*/
		samples[temp_a_id][3] = samples[temp_a_id][3]+2*labels[temp_a_id];
		samples[temp_a_id][7] = samples[temp_a_id][7]-2*labels[temp_a_id];
		
		/*class two*/
		samples[temp_b_id][3] = samples[temp_b_id][3]+2*labels[temp_b_id];
		samples[temp_b_id][7] = samples[temp_b_id][7]-2*labels[temp_b_id];	
	}
	
	/*init svm option*/
	options.nb_samples = nb_train_samples;
	options.nb_features = nb_of_features;
	
	/*train the svm*/
	psvm = train_svm(samples, labels, options);
	
	/*classify the test samples and output results*/
	for(i=0;i<nb_test_samples;i++){
		prdcted_labels[i] = classify_with_svm(psvm, samples[nb_train_samples+i]);
		
		cout <<  labels[nb_train_samples+i] << "   " << prdcted_labels[i] << endl;
	}
	
	cout << "save/load and test svm again" << endl;
	
	/*save and load the svm*/
	save_svm(psvm,"test_1");
	psvm2 = load_svm("test_1");
	
	/*classify the test samples and output results again, but this time with the loaded svm*/
	for(i=0;i<nb_test_samples;i++){
		prdcted_labels[i] = classify_with_svm(psvm2, samples[nb_train_samples+i]);
		
		cout <<  labels[nb_train_samples+i] << "   " << prdcted_labels[i] << endl;
	}	

	return EXIT_SUCCESS;
	
}
#endif
