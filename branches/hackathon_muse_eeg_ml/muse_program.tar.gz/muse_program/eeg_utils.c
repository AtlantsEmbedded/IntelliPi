
#include "eeg_utils.h"

void get_eeg_sample(double* sample, int label, int n){
	
	int i=0;
	
	if(label == 1){	
		for(i=0;i<n;i++){
			sample[i] = (0.5*(float)rand()/((float)RAND_MAX)+0.5)*sin(M_PI*20*i / n)+(0.5*(float)rand()/((float)RAND_MAX)+0.5)*sin(M_PI*44*i / n);
		}
	}
	else{
		for(i=0;i<n;i++){
			sample[i] = (0.5*(float)rand()/((float)RAND_MAX)-0.5)*sin(M_PI*20*i / n)+(0.5*(float)rand()/((float)RAND_MAX)-0.5)*sin(M_PI*44*i / n);
		}
	}
}

/**
 * randsample(int array[], int n)
 * 
 * @brief return an array of n elements. The array is the series of numbers [0, n-1] 
 *        randomly permutated a large number of times (n*10).
 *        This function will shortly be moce to a utils lib.
 * @param n, size of the array and range of the indexes
 * @param (out), array of size n, values will be set in the fonction
 */
void randsample(int array[], int n){
	
	int i;
	int nb_permut = n*10;
	int temp, source, dest; 
	time_t t;
	
	/*seed random generator*/
	srand((unsigned) time(&t));
	
	/*init the array with continuous numbers*/
	for(i=0;i<n;i++){
		array[i] = i;
	}
	
	/*do many permutations*/
	for(i=0;i<nb_permut;i++){
		
		/*pick two samples at random*/
		source = rand() % n;
		dest = rand() % n;
		
		/*permute them*/
		temp = array[source];
		array[source] = array[dest];
		array[dest] = temp;
	}
}

