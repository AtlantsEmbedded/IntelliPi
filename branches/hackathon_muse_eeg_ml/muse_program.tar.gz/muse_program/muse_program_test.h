#ifndef MUSE_PROGRAM_TEST_H
#define MUSE_PROGRAM_TEST_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fft.h"
#include "svm.h"
#include "eeg_utils.h"


void test_real_valued_fft(int n);
int test_svm();


#endif
