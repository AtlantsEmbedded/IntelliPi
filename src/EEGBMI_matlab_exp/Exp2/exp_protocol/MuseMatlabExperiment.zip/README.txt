
This Matlab program is used to run psychophysics experimental protocol for an EEG-BMI application.
It is based on a machine state for quick modifications of the experiment and the whole system is
loosely based on the MonkeyLab program.

It makes use of the psychtoolbox to control the display. If you don't need it, you can turn it off
easily by removing the screen object and all its reference.

You are free to use, modify or publish this program, but you need to acknoledge original credits 
to Fr�d�ric Simard, Atom Embedded, 2015.


