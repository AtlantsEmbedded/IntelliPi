



#include "decomp.h"


int compute_quantization(int quantizations);
void printbits(unsigned char v);

void parse_medians(char* medians_header, int* quantizations, int* medians)
{
	/*extract first median and first quantization*/
	medians[0] = (int)medians_header[0]&0x3f;
	quantizations[0] = (int)((medians_header[0]&0x3f)>>6 | (medians_header[1]&0x03)<<2);
	
	/*extract second median and second quantization*/
	medians[1] = (int)(medians_header[1]&0xfc)>>2;
	quantizations[1] = (int)(medians_header[2]&0x0f);
	
	/*extract third median and third quantization*/
	medians[2] = (int)((medians_header[2]&0xf0)>>4 | (medians_header[3]&0x03)<<4);
	quantizations[2] = (int)(medians_header[3]&0x3c)>>2;
	
	/*extract third median and third quantization*/
	medians[3] = (int)((medians_header[3]&0xc0)>>6 | (medians_header[4]&0x0f)<<2);
	quantizations[3] = (int)(medians_header[4]&0xf0)>>4;
	
	quantizations[0] = compute_quantization(quantizations[0]);
	quantizations[1] = compute_quantization(quantizations[1]);
	quantizations[2] = compute_quantization(quantizations[2]);
	quantizations[3] = compute_quantization(quantizations[3]);
	
}

int compute_quantization(int quantizations)
{
	int factor_2 = quantizations&0x01;
	int factor_4 = (quantizations&0x02)>>1;
	int factor_8 = (quantizations&0x04)>>2;
	int factor_16 = (quantizations&0x08)>>3;
	int temp = 1;
	
	if(factor_2)
		temp *= 2;
	
	if(factor_4)
		temp *= 4;
	
	if(factor_8)
		temp *= 8;
	
	if(factor_16)
		temp *= 16;
	
	return temp;
}


int parse_bit_length(char* bit_length_header)
{
	return (int)(bit_length_header[0]<<8 | (bit_length_header[1]&0xFF));
}



void parse_deltas(char* bits_header, int* median, int* quantization, int* deltas)
{
	int i,j,d=0;
	int bitshift = 0;
	int byteshift = 0;
	int delta_offset = 0;
	char quotient_parsed = 0;
	char cur_byte = 0;
	
	int quotient_value = 0;
	int reminder_value = 0;
	int sign_value = 0;
	
	int maxreminderbits = 0;
	int max1less = 0;
	int nb_zeros = 0;
	
	int elias_code = 0;
	
	char zeros_parsed = 0;
	
	cur_byte = bits_header[byteshift];
	
	
	printbits(cur_byte);
	
	/*for all quotient*/
	for(i=0;i<4;i++){
	//for(i=0;i<1;i++){
		
		
		//If median is 0
		if(median[i] == 0){
			printf("median==0\n");
			//	all data for set is 0 (16 diffs in set)
			//	skip 16 * 3 bits, Quotient 0, remainder 0, sign 1 (0 is positive sign)
			//	move to next median/channel

			for(j=0;j<16;j++){
				deltas[i+delta_offset]=0;
			}
			delta_offset += 16;
			byteshift += 6;
		}
		else
		{
			printf("median~=0\n");
			
			printf("Quotient\n");
			/*parse quotient*/
			if(median[i]<=14){
				//Unary Encoding
				printf("unary code\n");
				
				for(j=0;j<16;j++){
				//for(j=0;j<2;j++){
					
					/*parse out quotient*/
					quotient_parsed = 0;
					quotient_value = 0;
					
					printf("check1\n");
					
					
					//printbits(cur_byte);
					
					//printbits(cur_byte);
					
					/*count the number of ones before we reach a 0*/
					while(quotient_parsed==0){
						
						printbits(cur_byte);
						printf("\n");
						if((cur_byte&0x80)){
							quotient_value++;
						}
						else
						{
							//printbits(cur_byte);
							quotient_parsed = 1;
						}
						
						cur_byte = cur_byte<<1;
						bitshift++;
						
						if(bitshift >= 8){
							byteshift+=1;
							bitshift = 0;
							cur_byte = bits_header[byteshift];
						}
					}
					
					
					printf("quotient_value: %i\n",quotient_value);
					
					
					
					printf("Reminder\n");
					reminder_value = 0;
					
					#if 1
					 // SECOND CALCULATE REMAINDER
					int maxreminderbits = (int)floor(log2((double)median[i]));// (int)(Math.Log(median[ch]) / Math.Log(2));
					int max1less = (int)pow(2.0, (double)(maxreminderbits+1)) - median[i]; // The maximium value for not using an extra bit                        
					//if (debugview) System.Diagnostics.Debug.WriteLine("MAXLESS:" + maxreminderbits + "," + median[ch] + ", " + max1less);

					printf("maxreminderbits: %i\n",maxreminderbits);
					printf("max1less: %i\n",max1less);

					printbits(cur_byte); 
					
					/*push in the minimum number of bits*/
					for (d = 0; d < maxreminderbits; d++){
						reminder_value = reminder_value<<1;
						
						if(cur_byte&0x80){
									
							printf("Reminder value: ");
							printbits(reminder_value);
							
							reminder_value = reminder_value | 0x01;
							printf("\ncheck1\n");
							
							printf("Reminder value: ");
							printbits(reminder_value);
						}
						
						cur_byte = cur_byte<<1;
						bitshift++;
					
						if(bitshift >= 8){
							byteshift += 1;
							bitshift = 0;
							cur_byte = bits_header[byteshift];
						}
						
					}
					
					printf("Reminder value: ");
					printbits(reminder_value);
					printf("\n");
					
					/*check if another bit is required*/
					if (reminder_value >= max1less)  
					{
						printf("check\n");
						//if (debugview) System.Diagnostics.Debug.WriteLine("NEEDS TO BE 1 BIT MORE!!!");
						
						maxreminderbits++;
						
						
						for (; d < maxreminderbits; d++){
							reminder_value = reminder_value << 1;
							
							if(cur_byte&0x80){
								reminder_value = reminder_value | 0x01;
									
								printf("Reminder value: ");
								printbits(reminder_value);
							}
							
							cur_byte = cur_byte<<1;
							bitshift++;
						
							if(bitshift >= 8){
								byteshift += 1;
								bitshift = 0;
								cur_byte = bits_header[byteshift];
							}
							
						}
						
						reminder_value = reminder_value - max1less;
					}
					
					printf("Reminder value: ");
					printbits(reminder_value);
					printf("\n");
					
					//if (maxreminderbits == 0)
					//	bitshift++;

					//bitshift += maxreminderbits;
					#endif
					
					printf("Sign\n");
					
					printbits(cur_byte); 
					
					/*parse out sign*/
					if(cur_byte&0x80){
						sign_value = 1;
					}
					else{
						sign_value = -1;
					}
											
					cur_byte = cur_byte<<1;
					bitshift++;
						
					if(bitshift >= 8){
						printf("check\n");
						byteshift+=1;
						bitshift = 0;
						cur_byte = bits_header[byteshift];
					}
					
					printf("sign_value: %i\n",sign_value);
					
					/*compute deltas*/
					deltas[i] = (quotient_value * median[i] + reminder_value) * sign_value * quantization[i];
					
					printf("Deltas[i]: %i\n",deltas[i]);
					
				}
			}
			else
			{
				for(j=0;j<16;j++){
			
				//Elias Encoding 
				/*starts with 15 ones*/
				for (d = 0; d < 15; d++){
					
					cur_byte = cur_byte<<1;
					bitshift++;
						
					if(bitshift >= 8){
						printf("check\n");
						byteshift+=1;
						bitshift = 0;
						cur_byte = bits_header[byteshift];
					}
					
				}
				
				/*then N-1 zeros*/
				zeros_parsed = 0;
				nb_zeros = 0;
				
				while(~zeros_parsed){
				
					if((cur_byte&0x80)){
						zeros_parsed = 1;
					}
					else
					{
						nb_zeros = nb_zeros+1;
						cur_byte = cur_byte<<1;
						bitshift++;
						
						if(bitshift >= 8){
							byteshift+=1;
							bitshift = 0;
							cur_byte = bits_header[byteshift];
						}
					}
				}
				
				
				quotient_value = 0;
				/*read the N bits that follows*/
				for (d = 0; d <= nb_zeros; d++){
					
					quotient_value = elias_code<<1;
					
					if((cur_byte&0x80)){
						zeros_parsed = 1;
						quotient_value = elias_code|0x01;
						
					}
					else
					{
						quotient_value = elias_code|0x00;
					}
					
					cur_byte = cur_byte<<1;
					bitshift++;
					
					if(bitshift >= 8){
						byteshift+=1;
						bitshift = 0;
						cur_byte = bits_header[byteshift];
					}
					
					
				}
				
					
					printf("Reminder\n");
					reminder_value = 0;
					
					#if 1
					 // SECOND CALCULATE REMAINDER
					int maxreminderbits = (int)floor(log2((double)median[i]));// (int)(Math.Log(median[ch]) / Math.Log(2));
					int max1less = (int)pow(2.0, (double)(maxreminderbits+1)) - median[i]; // The maximium value for not using an extra bit                        
					//if (debugview) System.Diagnostics.Debug.WriteLine("MAXLESS:" + maxreminderbits + "," + median[ch] + ", " + max1less);

					printf("maxreminderbits: %i\n",maxreminderbits);
					printf("max1less: %i\n",max1less);

					printbits(cur_byte); 
					
					/*push in the minimum number of bits*/
					for (d = 0; d < maxreminderbits; d++){
						reminder_value = reminder_value<<1;
						
						if(cur_byte&0x80){
									
							printf("Reminder value: ");
							printbits(reminder_value);
							
							reminder_value = reminder_value | 0x01;
							printf("\ncheck1\n");
							
							printf("Reminder value: ");
							printbits(reminder_value);
						}
						
						cur_byte = cur_byte<<1;
						bitshift++;
					
						if(bitshift >= 8){
							byteshift += 1;
							bitshift = 0;
							cur_byte = bits_header[byteshift];
						}
						
					}
					
					printf("Reminder value: ");
					printbits(reminder_value);
					printf("\n");
					
					/*check if another bit is required*/
					if (reminder_value >= max1less)  
					{
						printf("check\n");
						//if (debugview) System.Diagnostics.Debug.WriteLine("NEEDS TO BE 1 BIT MORE!!!");
						
						maxreminderbits++;
						
						
						for (; d < maxreminderbits; d++){
							reminder_value = reminder_value << 1;
							
							if(cur_byte&0x80){
								reminder_value = reminder_value | 0x01;
									
								printf("Reminder value: ");
								printbits(reminder_value);
							}
							
							cur_byte = cur_byte<<1;
							bitshift++;
						
							if(bitshift >= 8){
								byteshift += 1;
								bitshift = 0;
								cur_byte = bits_header[byteshift];
							}
							
						}
						
						reminder_value = reminder_value - max1less;
					}
					
					printf("Reminder value: ");
					printbits(reminder_value);
					printf("\n");
					
					//if (maxreminderbits == 0)
					//	bitshift++;

					//bitshift += maxreminderbits;
					#endif
					
					printf("Sign\n");
					
					printbits(cur_byte); 
					
					/*parse out sign*/
					if(cur_byte&0x80){
						sign_value = 1;
					}
					else{
						sign_value = -1;
					}
											
					cur_byte = cur_byte<<1;
					bitshift++;
						
					if(bitshift >= 8){
						printf("check\n");
						byteshift+=1;
						bitshift = 0;
						cur_byte = bits_header[byteshift];
					}
					
					printf("sign_value: %i\n",sign_value);
					
					/*compute deltas*/
					deltas[i] = (quotient_value * median[i] + reminder_value) * sign_value * quantization[i];
					
					printf("Deltas[i]: %i\n",deltas[i]);
					
				}
			}
		}
	}
}


void printbits(unsigned char v) {
  int i; // for C89 compatability
  for(i = 7; i >= 0; i--) putchar('0' + ((v >> i) & 1));
}
