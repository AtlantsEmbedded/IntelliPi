
#ifndef DECOMP_H
#define DECOMP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


void parse_medians(char* medians_header, int* quantizations, int* medians);

int parse_bit_length(char* bit_length_header);

void parse_deltas(char* bits_header, int* median, int* quantization, int* deltas);








#endif


