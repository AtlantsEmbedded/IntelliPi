

#include "decomp.h"


int main(void)
{
	
	char medians_header_a[5] = {0x0e,0x3c,0xc0,0xc0,0x03};
	char medians_header_b[5] = {0x05,0x08,0x78,0x40,0x81};
	
	char bit_length_header_a[2] = {0x01,0x9b};
	char bit_length_header_b[2] = {0x01,0x87};
	
	int delta_medians[5] = {6,6,6,6,6};
	int deltas[16];
	int delta_quantization[5] = {1,1,1,1,1};
	char deltas_header[2] = {0xBe,0x00};
	
	int* quantizations = (int*)malloc(sizeof(int)*5);
	int* medians = (int*)malloc(sizeof(int)*5);
	int bit_length = 0;
	
	#if 1
	parse_medians(medians_header_a, quantizations, medians);
	
	printf("medians[0]:%i\n",medians[0]);
	printf("quantizations[0]:%i\n",quantizations[0]);
	printf("medians[1]:%i\n",medians[1]);
	printf("quantizations[1]:%i\n",quantizations[1]);
	printf("medians[2]:%i\n",medians[2]);
	printf("quantizations[2]:%i\n",quantizations[2]);
	printf("medians[3]:%i\n",medians[3]);
	printf("quantizations[3]:%i\n",quantizations[3]);
	printf("\n");
	
	parse_medians(medians_header_b, quantizations, medians);
	
	printf("medians[0]:%i\n",medians[0]);
	printf("quantizations[0]:%i\n",quantizations[0]);
	printf("medians[1]:%i\n",medians[1]);
	printf("quantizations[1]:%i\n",quantizations[1]);
	printf("medians[2]:%i\n",medians[2]);
	printf("quantizations[2]:%i\n",quantizations[2]);
	printf("medians[3]:%i\n",medians[3]);
	printf("quantizations[3]:%i\n",quantizations[3]);
	printf("\n");
	
	bit_length = parse_bit_length(bit_length_header_a);
	printf("bit_length:%i\n",bit_length);
	bit_length = parse_bit_length(bit_length_header_b);
	printf("bit_length:%i\n",bit_length);
	
	#endif
	
	parse_deltas(deltas_header, delta_medians, delta_quantization, deltas);
	
	
}


